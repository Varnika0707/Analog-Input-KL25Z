# Lab5: Using Analog to Digital Convertor (ADC)

Starter code for Lab 5
  *  Press B1 to use ADC to measure voltage
  *  When green LED is on, VR1 is measured
  *  When red LED is on, VR2 is measured
  *  Both measurements update 'scaled' variable
  *  Observe variables using debugger
