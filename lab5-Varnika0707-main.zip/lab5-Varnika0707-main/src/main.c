/* ------------------------------------------
       ECS642/ECS714 Lab 5 Given Code
    
   Press B1 to use ADC to measure voltage
   When green LED is on, VR1 is measured
   When red LED is on, VR2 is measured
   Both measurements update 'scaled' variable    
  -------------------------------------------- */

#include <MKL25Z4.h>
#include <stdbool.h>
#include "../include/SysTick.h"
#include "../include/button.h"
#include "../include/rgb.h"
#include "../include/led.h"
#include "../include/adc.h"

#define V1min 0
#define V1max 298
#define V2min 0
#define V2max 297

#define MAXONTIME 3
#define MAXOFFTIME 3
#define MINONTIME 0.5
#define MINOFFTIME 0.5

/* --------------------------------------
     Documentation
     =============
     This is a cyclic system with a cycle time of 10ms

     The file has a main function, with two tasks
        1. task1PollB1 polls button B1
        2. task2MeasureVR uses ADC to measure voltage on each button press
 -------------------------------------- */
 
/* --------------------------------------------
  Variables for communication
*----------------------------------------------------------------------------*/
bool pressedB1_ev ;  // set by task1 (polling) and cleared by task 2

/*----------------------------------------------------------------------------
  task1pollB1
  
  This task polls button B1. Keep this task.
*----------------------------------------------------------------------------*/
int b1State ;        // Current state - corresponds to position
int b1BounceCount ;

void initTask1PollB1() {
    b1State = BOPEN ;
    pressedB1_ev = false ; 
    b1BounceCount = 0 ;
}

void task1PollB1() {
    if (b1BounceCount > 0) b1BounceCount -- ;
    switch (b1State) {
        case BOPEN:
            if (isPressed(B1MASK)) {
                b1State = BCLOSED ;
                pressedB1_ev = true ; 
            }
          break ;

        case BCLOSED:
            if (!isPressed(B1MASK)) {
                b1State = BBOUNCE ;
                b1BounceCount = BOUNCEDELAY ;
            }
            break ;

        case BBOUNCE:
            if (isPressed(B1MASK)) {
                b1State = BCLOSED ;
            }
            else if (b1BounceCount == 0) {
                b1State = BOPEN ;
            }
            break ;
    }                
}


/*----------------------------------------------------------------------------
   Task: task2MeasureVR

   This task use steh ADC to get the voltage 
*----------------------------------------------------------------------------*/

VR_t vrState ;        // Current state - which VR measured next

volatile uint16_t vr1 ;      // raw value - single ended
volatile uint16_t vr2 ;      // raw value - single ended
int scaled ; // voltage as a scaled integer - 3v shown as 300
int measure_counter = 0;//This variable will make sure that the measurement on the two voltages vr1 and vr2 cAN 
void initTask2MeasureVR() {
    vrState = VR1 ;//initial state 
    //setRGB(RED, RGB_OFF) ;
    //setRGB(GREEN, RGB_ON) ;
}

void task2MeasureVR(){
	//waitSysTickCounter(20) ;
	
	
	if (measure_counter == 1)
	{
	vr1 = MeasureVR(VR1);
	scaled = (vr1 * 330) / 0xFFFF ;
	
	
		
		measure_counter = 0;
	}
  else
		{
			vr2 = MeasureVR(VR2) ;
  scaled = (vr2 * 330) / 0xFFFF ;
 measure_counter++;
	}
}
	
/*
void task2MeasureVR() {
		waitSysTickCounter(20) ;
    switch (vrState) {
        case VR1:
            vr1 = MeasureVR(VR1) ;
            scaled = (vr1 * 330) / 0xFFFF ;
            // Max voltage is 3.3 v
            // Using 16 bit accuracy, raw value is 0xFFFF
            // Result represents voltage N.NN as integer NNN
             vrState = VR2 ;
             setRGB(RED, RGB_ON) ;
             setRGB(GREEN, RGB_OFF) ;
						 //waitSysTickCounter(20) ;//measuring vr1 every 20ms
            
        break ;
        
        case VR2: 
             vr2 = MeasureVR(VR2) ;
             scaled = (vr2 * 330) / 0xFFFF ;
             vrState = VR1 ;
             setRGB(RED, RGB_OFF) ;
             setRGB(GREEN, RGB_ON) ;
						 //waitSysTickCounter(20) ;//measuring vr2 every 20ms
        break ;
        
        default: // other case not needed
            break ; 
    }
}
*/

/*----------------------------------------------------------------------------
  task3ShieldLEDs function

	This function is implementing the State Transition Diagram with three states.
 *----------------------------------------------------------------------------*/

//Defining MACROS for all the three states of the State Transition Diagram
#define ShieldLEDsON 6
#define ShieldLEDsOFF 7
#define FlashOFF 8

//int num = 0;

int LED_State;//This is the initial state of the shield LEDs
//int LEDs[] = {LED1, LED2, LED3, LED4, LED5};//Array of all the 5 shield LEDs
int Counter;

void initTask3ShieldLEDs(){
			Counter=0;
			LED_State = ShieldLEDsON;
			setRGB(GREEN, RGB_ON);
	    ledOnOff(LED1,LED_ON);
			ledOnOff(LED2,LED_ON);
			ledOnOff(LED3,LED_ON);
			ledOnOff(LED4,LED_ON);
			ledOnOff(LED5,LED_ON);	
}


/*

void task3ShieldLEDs() {
		switch(LED_State){
			case ShieldLEDsON:
				Counter++;
			 if((V1max-V1min)*Counter>=250*(v1-V1min)+50*(V1max-V1min)){
					ledOnOff(LED1,LED_OFF);
					ledOnOff(LED2,LED_OFF);
					ledOnOff(LED3,LED_OFF);
					ledOnOff(LED4,LED_OFF);
					ledOnOff(LED5,LED_OFF);
			LED_State=ShieldLEDsOFF;	
				  Counter=0;
			}
			 
				if(pressedB1_ev){
				  pressedB1_ev=false;//acknowledge the event
				
					ledOnOff(LED1,LED_OFF);
					ledOnOff(LED2,LED_OFF);
					ledOnOff(LED3,LED_OFF);
					ledOnOff(LED4,LED_OFF);
					ledOnOff(LED5,LED_OFF);
					setRGB(GREEN,RGB_OFF);//Turn off GREEN color LED
					setRGB(RED,RGB_ON);//Turn on RED color LED
					LED_State=FlashOFF;
			}
				break;
			case ShieldLEDsOFF:
				break;
			case FlashOFF:
				break;
		}
}*/

void task3ShieldLEDs(){
			int v1=(int)vr1;
      int v2=(int)vr2;
	switch(LED_State){
		case ShieldLEDsON:
			Counter++;
			if((V1max-V1min)*Counter>=250*(v1-V1min)+50*(V1max-V1min)){
					ledOnOff(LED1,LED_OFF);
					ledOnOff(LED2,LED_OFF);
					ledOnOff(LED3,LED_OFF);
					ledOnOff(LED4,LED_OFF);
					ledOnOff(LED5,LED_OFF);
			LED_State=ShieldLEDsOFF;	
				  Counter=0;//reset the counter 
			}
			//break;
			
			if(pressedB1_ev){
				  pressedB1_ev=false;//acknowledge the event
				
					ledOnOff(LED1,LED_OFF);
					ledOnOff(LED2,LED_OFF);
					ledOnOff(LED3,LED_OFF);
					ledOnOff(LED4,LED_OFF);
					ledOnOff(LED5,LED_OFF);
					setRGB(GREEN, RGB_OFF);//Turn off Green color
					setRGB(RED,RGB_ON);//Turn on RED color LED
					LED_State=FlashOFF;
			
			}
			break;
				
	 
		case ShieldLEDsOFF:
			Counter++;
			if((V2max-V2min)*Counter>=250*(v2-V2min)+50*(V2max-V2min)){
					ledOnOff(LED1,LED_ON);
					ledOnOff(LED2,LED_ON);
					ledOnOff(LED3,LED_ON);
					ledOnOff(LED4,LED_ON);
					ledOnOff(LED5,LED_ON);
			LED_State=ShieldLEDsON;
				Counter=0;//reset the counter
			}
			//break;
			
			if(pressedB1_ev){
				pressedB1_ev=false;//acknowledge the event
				setRGB(RED,RGB_ON);//Turn on RED color LED
				LED_State=FlashOFF;
			}
			
			break;
			
		case FlashOFF:
			if(pressedB1_ev){
				pressedB1_ev=false;//acknowledge the event
					ledOnOff(LED1,LED_ON);
					ledOnOff(LED2,LED_ON);
					ledOnOff(LED3,LED_ON);
					ledOnOff(LED4,LED_ON);
					ledOnOff(LED5,LED_ON);
				setRGB(RED,RGB_OFF);//Turn on RED color LED
				setRGB(GREEN,RGB_ON);//Turn ON GREEN color LED
				LED_State=ShieldLEDsON;
			}
		break;
				
	}


}

/*----------------------------------------------------------------------------
  MAIN function
 *----------------------------------------------------------------------------*/
int main (void) {

    // Initialise peripherals
    configureButtons(B1MASK, false) ; // ConfigureButtons B1 for polling
    configureLEDs() ;                 // Configure shield LEDs
    configureRGB();                   // 
    
    // Initialise and calibrate ADC
    initADC() ; // Initialise ADC
    int calibrationFailed = ADC_Cal(ADC0) ; // calibrate the ADC 
     
		Init_SysTick(1000);
	
    // Initialise tasks and cycle counter
    initTask1PollB1() ;  
    initTask2MeasureVR() ;
		initTask3ShieldLEDs();
    waitSysTickCounter(10) ;  
    
    while (1) {      // this runs forever
        task1PollB1() ;    // Generate signals for a simulated button
				task2MeasureVR() ; // 
			  //waitSysTickCounter(20) ; 
				task3ShieldLEDs();
        // delay
        waitSysTickCounter(10) ;  // cycle every 10 ms 
    }
}
